# IRIS (with embedded Automation Code Review subsystem) · Merged Architecture

A single unified view of two systems presented as one platform:

- **IRIS** — the QEA Banking Agent Orchestration Platform (Node/Express + React), which orchestrates
  ~15 autonomous agents. State is file-based (`context/`, `logs/`).
- **Automation Code Review Agent (ACR)** — a Python/FastAPI + CrewAI multi-agent reviewer, which is the
  implementation **behind IRIS's `automation-code-review` agent**. State is file + SQLite.

**How they connect:** IRIS's `automation-code-review-executor` calls the ACR FastAPI service over
**HTTP (REST + SSE) on `:8000`** — the same pattern as IRIS's `python-bridge-service`. The two remain
separate processes with their own state; IRIS is the umbrella orchestrator and ACR is one deep
capability it invokes.

> Rendered visual version: [`iris-merged-architecture.html`](./iris-merged-architecture.html).
> Standalone per-system docs: [IRIS](./IRIS-ARCHITECTURE.md) · [ACR](./AUTOMATION-CODE-REVIEW-ARCHITECTURE.md).

---

## a. Merged system context / container view

```mermaid
graph TB
    user(["User (browser)"])

    subgraph IRIS["IRIS — QEA Banking Platform (Node/Express)"]
        fe["Frontend · React SPA (:5173)"]
        be["Backend · Express (:3001)<br/>AgentOrchestrator"]
        acragent["automation-code-review agent + executor<br/>(1 of ~15 IRIS agents · HTTP client)"]
        other["other IRIS agents<br/>testcase-gen · brd-mapper · traceability-matrix · …"]
    end

    subgraph ACR["Automation Code Review subsystem — Python / FastAPI (:8000) · CrewAI"]
        api["FastAPI main.py (:8000)<br/>REST + SSE"]
        crew["StreamingReviewCrew<br/>6 CrewAI agents (parallel)"]
        support["Tools · RAG (ChromaDB) · Evaluation"]
    end

    subgraph EXT["Shared externals"]
        bridge["Local LLM Bridge (:3000, shared) + judge (:3030)"]
        anth["Anthropic / OpenAI (IRIS)"]
        azure["Azure OpenAI (ACR)"]
        saas["Jira · Confluence · Xray / JTMF"]
    end

    subgraph STATE["Local file / DB state"]
        iristate[("IRIS: context/ · logs/")]
        acrstate[("ACR: uploads/ · reports/ · rag_store/ · eval_history/")]
    end

    user --> fe --> be
    be --> acragent
    be --> other
    acragent -->|"HTTP · REST + SSE (:8000)"| api
    api --> crew --> support
    be --> bridge
    be --> saas
    be --> anth
    support --> azure
    support --> bridge
    be <--> iristate
    api <--> acrstate
```

**Legend**
- **IRIS** (umbrella) — React SPA (:5173) + Express backend (:3001) with the `AgentOrchestrator` and ~15 agents.
- **`automation-code-review` agent** — the one IRIS agent whose executor is an HTTP client into the ACR subsystem.
- **ACR subsystem** — a self-contained FastAPI (:8000) + CrewAI service (6 agents, Tools, RAG, Evaluation).
- **Shared externals** — the local LLM bridge (:3000, used by both), Anthropic/OpenAI (IRIS), Azure OpenAI (ACR), and the SaaS IRIS integrates with.
- **State** — each subsystem owns its own on-disk state; there is no shared database.

---

## b. Integration boundary — how IRIS invokes ACR over HTTP

```mermaid
graph LR
    subgraph IRISZONE["IRIS process (Node / Express :3001)"]
        orch["AgentOrchestrator"]
        agent["automation-code-review agent"]
        exec["automation-code-review-executor<br/>HTTP client"]
        ctx[("context/ — RTM / report output")]
    end

    boundary{{"Process / HTTP boundary"}}

    subgraph ACRZONE["ACR process (Python / FastAPI :8000)"]
        api["FastAPI /review/stream"]
        crew["StreamingReviewCrew"]
        agents["6 CrewAI agents<br/>+ Tools + RAG + Evaluation"]
    end

    orch --> agent --> exec
    exec -->|"1 POST /review/stream (code, agents)"| boundary
    boundary --> api --> crew --> agents
    agents -. SSE findings .-> api
    api -. "2 SSE stream" .-> boundary
    boundary -. stream .-> exec
    exec -->|"3 write result"| ctx
```

**Legend**
- **IRIS zone** — the orchestrator resolves the `automation-code-review` agent, whose executor is an HTTP client.
- **HTTP boundary** — the two systems are separate processes; the executor calls ACR's `/review/stream` (REST + SSE).
- **ACR zone** — FastAPI receives the request, runs `StreamingReviewCrew`, and streams findings back over SSE.
- **Return path** — the executor consumes the SSE stream and writes the result (RTM / report) into IRIS `context/`.

---

## c. IRIS backend — the `automation-code-review` bridge (★)

```mermaid
graph TB
    axiosIn["Axios from IRIS Frontend (:3001)"]

    subgraph SERVER["IRIS Backend — server/ (Express, :3001)"]
        index["index.js · routers · /health"]
        orch["orchestrator.js — AgentOrchestrator"]
        exe["agent-executor.js"]
        subgraph EXECS["server/agents/*.js (executors)"]
            acr["automation-code-review-executor ★"]
            rest["testcase-gen · brd-mapper · traceability-matrix · …"]
        end
        acrbridge["ACR HTTP client<br/>(python-bridge-service style)"]
    end

    acrsvc["ACR subsystem — FastAPI (:8000)"]
    ctx[("context/")]

    axiosIn --> index --> orch --> exe
    exe --> acr
    exe --> rest
    acr --> acrbridge -->|"HTTP REST + SSE"| acrsvc
    rest <--> ctx
    acr --> ctx
```

**Legend**
- **AgentOrchestrator** routes to `agent-executor.js`, which dispatches to the per-agent executors.
- **★ `automation-code-review-executor`** — unlike the other executors (which run locally against `context/`), this one delegates to the ACR subsystem via an HTTP client.
- Results returned from ACR are written back into IRIS `context/` for the report/RTM pipeline.

---

## d. ACR subsystem internals — what IRIS calls

```mermaid
graph TB
    incoming["HTTP from IRIS → POST /review/stream"]

    subgraph MAIN["ACR backend/main.py — FastAPI (:8000)"]
        eps["endpoints: /upload · /review/stream · /rag/* · /report · /history"]
    end

    crew["StreamingReviewCrew (backend/crew/)<br/>parallel specialists · SSE queue"]

    subgraph AGENTS["backend/agents/ — 6 CrewAI agents"]
        a["code_quality · security · anti_pattern<br/>best_practices · performance · report"]
    end

    subgraph SUP["Support layers"]
        tools["Tools — radon · pyflakes · bandit"]
        rag["RAG — ChromaDB"]
        evalx["Evaluation — judge · DeepEval · drift"]
    end

    llm["Azure OpenAI / LLM Bridge"]
    stores[("uploads/ · reports/ · rag_store/ · eval_history/ (SQLite)")]

    incoming --> eps --> crew --> AGENTS
    a --> tools
    a --> rag
    a --> llm
    crew --> evalx
    crew --> stores
```

**Legend**
- The request from IRIS lands on FastAPI's `/review/stream`, which drives `StreamingReviewCrew`.
- The crew fans out the six CrewAI agents (parallel), each using static-analysis Tools, RAG context, and an LLM.
- Evaluation scores the run and the four on-disk stores persist code, reports, the vector store, and the SQLite drift DB.
- (Full detail: [ACR standalone doc](./AUTOMATION-CODE-REVIEW-ARCHITECTURE.md).)

---

## e. Merged deployment / process view

```mermaid
graph TB
    subgraph HOST["Local host — multiple processes"]
        launch["IRIS launcher / start.js"]
        fe["IRIS Frontend · Vite (:5173)"]
        be["IRIS Backend · Express (:3001)"]
        bridge["LLM Bridge (:3000, shared) + judge (:3030)"]
        chrome["System Chrome (CDP)"]
        acr["ACR · FastAPI + Uvicorn (:8000)"]
        subgraph ST["File / DB state"]
            iris[("IRIS context/ · logs/")]
            acrst[("ACR uploads/ · reports/ · rag_store/ · eval_history/ (SQLite)")]
        end
    end

    subgraph CLOUD["External"]
        anth["Anthropic / OpenAI"]
        azure["Azure OpenAI"]
        saas["Jira · Confluence · Xray / JTMF"]
    end

    launch --> fe
    launch --> be
    fe -->|":3001"| be
    be -->|"HTTP :8000"| acr
    be -->|":3000"| bridge
    be -->|"CDP"| chrome
    be <--> iris
    acr <--> acrst
    acr -.->|":3000 shared / Azure"| bridge
    acr --> azure
    be --> anth
    be --> saas
```

**Legend**
- **Processes** — IRIS Frontend (`:5173`), IRIS Backend (`:3001`), the shared LLM Bridge (`:3000`), system Chrome, and the **ACR FastAPI process (`:8000`)**, all local. The IRIS backend calls ACR over HTTP.
- **Port note** — both IRIS's `enhanced-bridge.js` and ACR's Copilot bridge target `:3000`; on one host they must share the bridge (or ACR uses Azure / a different port). Called out to avoid a collision.
- **State** — each subsystem keeps its own files; IRIS uses `context/`+`logs/`, ACR uses `uploads/`/`reports/`/`rag_store/`/`eval_history/` (SQLite). No shared DB.
- **External** — IRIS reaches Jira/Confluence/Xray and Anthropic/OpenAI; ACR reaches Azure OpenAI (and the shared bridge).

---

## f. Merged end-to-end sequence — an `automation-code-review` run

```mermaid
sequenceDiagram
    actor User
    participant FE as IRIS Frontend (:5173)
    participant BE as IRIS Backend / Orchestrator (:3001)
    participant API as ACR FastAPI (:8000)
    participant CREW as StreamingReviewCrew
    participant ST as IRIS context/ + report

    User->>FE: run automation-code-review
    FE->>BE: trigger agent (Axios)
    BE->>BE: orchestrator resolves automation-code-review-executor
    BE->>API: HTTP POST /review/stream (code, selected agents)
    API->>CREW: run() (thread pool, parallel specialists)

    loop each specialist finding
        CREW-->>API: SSE finding
        API-->>BE: SSE event
        BE-->>FE: SSE status (live)
    end

    CREW->>API: Report agent → ReportSummary
    API-->>BE: final report (SSE end)
    BE->>ST: write context/ + report (RTM / audit)
    BE-->>FE: result + report link
```

**Legend**
- The user triggers the `automation-code-review` agent from the IRIS UI; the orchestrator resolves its executor.
- The executor makes one HTTP call to ACR's `/review/stream`; ACR runs the CrewAI crew in parallel.
- Findings stream back over SSE through the IRIS backend to the browser as they land.
- On completion, ACR returns the `ReportSummary`; IRIS writes the result into `context/` and surfaces it in the UI.

---

*Faithful to both inventories: ACR is modelled as the implementation behind IRIS's existing
`automation-code-review` agent, reached over HTTP (REST + SSE). No new databases, queues, or cloud
services introduced; each subsystem retains its own file/SQLite state and its own process.*
