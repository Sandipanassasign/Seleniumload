# Architecture docs — index & guide

This folder holds architecture references for three things: **IRIS** (the QEA orchestration platform),
the **Automation Code Review Agent (ACR)**, and the **merged** view where ACR is the subsystem behind
IRIS's `automation-code-review` agent.

## Files

| System | Markdown (Mermaid) | Standalone HTML | Confluence SVGs + zip |
|---|---|---|---|
| IRIS | [IRIS-ARCHITECTURE.md](./IRIS-ARCHITECTURE.md) | [iris-architecture.html](./iris-architecture.html) | [diagrams/](./diagrams) · [iris-confluence-bundle.zip](./iris-confluence-bundle.zip) |
| Automation Code Review | [AUTOMATION-CODE-REVIEW-ARCHITECTURE.md](./AUTOMATION-CODE-REVIEW-ARCHITECTURE.md) | [automation-code-review-architecture.html](./automation-code-review-architecture.html) | [diagrams-acr/](./diagrams-acr) · [acr-confluence-bundle.zip](./acr-confluence-bundle.zip) |
| **Merged** | [IRIS-MERGED-ARCHITECTURE.md](./IRIS-MERGED-ARCHITECTURE.md) | [iris-merged-architecture.html](./iris-merged-architecture.html) | [diagrams-merged/](./diagrams-merged) · [iris-merged-confluence-bundle.zip](./iris-merged-confluence-bundle.zip) |

Each set covers six views: **a** container · **b** integration/orchestration · **c** IRIS backend ·
**d** ACR internals · **e** deployment · **f** end-to-end sequence.

---

## How the orchestration works

The merged system has **two orchestration layers, nested** — IRIS decides *which* agent runs and drives
the QEA workflow; ACR decides *how* the code review is performed internally. They meet at one seam (the
HTTP call).

### Layer 1 — IRIS orchestration (Node/Express, `AgentOrchestrator`)
1. **Load & register** — on startup, reads agent definitions from `agents/*.prompt.md`, extracts YAML
   metadata, detects parent/sub-agent relationships, and builds the agent registry (~15 agents).
2. **Resolve & dispatch** — a UI trigger hits the Express route (`:3001`); the orchestrator resolves the
   requested agent and hands it to `agent-executor.js`, which dispatches to `server/agents/*.js`.
3. **Execute** — most executors run locally against `context/`. The `automation-code-review-executor` is
   the exception: it is an HTTP client into the ACR subsystem.
4. **Track & stream** — tracks active executions, retries failures, and streams status to the React UI
   over SSE.

### The hand-off (the one seam)
The `automation-code-review-executor` makes a single call — `POST /review/stream` to ACR on `:8000` —
passing the code + selected specialists, then consumes the SSE stream ACR returns. On completion it
writes the result (RTM/report) into IRIS `context/`. (See diagram **b**.)

### Layer 2 — ACR orchestration (Python, CrewAI `StreamingReviewCrew`)
- CrewAI supplies `Agent` / `Task` / `Crew` / `Process` and routes model calls through **litellm**, so
  `get_llm()` swaps Azure ↔ bridge transparently.
- CrewAI's native `Process` is sequential/blocking, so `StreamingReviewCrew` adds a custom two-phase
  **map/reduce**:
  - **Phase 1 — fan-out (map):** each selected specialist is a CrewAI `Agent` + `Task`, run concurrently
    on a `ThreadPoolExecutor` with its tools (radon/pyflakes/bandit) + RAG context + LLM. Each result is
    validated (Pydantic `AgentResult`), fact-checked, judged (LLM-as-Judge / DeepEval), and pushed as an
    SSE event onto an `asyncio.Queue`.
  - **Phase 2 — synthesis (reduce):** after the barrier, the Report agent consolidates all findings into
    a `ReportSummary`, written to `reports/` and logged to the SQLite drift store.

### How the layers compose
The **SSE stream chains through both layers**: a finding produced in ACR's crew → ACR FastAPI → (HTTP) →
IRIS executor → IRIS backend → IRIS frontend, live. The user watching the IRIS UI sees each finding in
real time even though the review runs in a separate Python process. (See diagram **f**.)

In one line: **IRIS orchestrates the workflow and picks the agent; ACR orchestrates the multi-agent
review; SSE glues their streaming together across the HTTP boundary.**

---

## Understanding the standalone HTML files

The `*-architecture.html` files are **single, self-contained HTML documents** — no server, no build step,
no internet. Open one in any browser and all six diagrams render.

### Structure
- **`<style>` in `<head>`** —
  1. CSS variables for the palette (surfaces, text, borders), with a `@media (prefers-color-scheme: dark)`
     block and a `[data-theme="dark"]` override that redefine the same variables — so every colour flips
     for dark mode automatically.
  2. SVG helper classes: `.t` / `.th` / `.ts` (text sizes), `.arr` / `.arr2` / `.leader` (arrows and the
     dashed leader/return lines).
  3. Colour-ramp classes `.c-blue … .c-gray` — each sets a box fill+stroke and text colour, with a
     dark-mode variant. Same markup reads correctly in both themes.
- **Sticky theme-toggle button** (top-right).
- **`<header>`** — title + intro.
- **`<main>`** — six sections, each: `<h2>` heading, intro `<p>`, a `.card` holding one inline `<svg>`,
  and a `.legend` bullet list.
- **`<footer>`** + a tiny `<script>` that cycles the `data-theme` attribute on click.

### How the diagrams are drawn
Inline SVG with `viewBox="0 0 680 …"`, built from `<rect>` boxes, `<text>` labels, and `<line>`/`<path>`
connectors with a shared arrowhead marker. Colours come only from the `c-*` classes — no raster images,
no external fonts (system fonts) — which is what makes the files fully portable and offline-safe.

### How to use
- Open: double-click, or `start docs\iris-merged-architecture.html`.
- Toggle light/dark with the top-right button (defaults to your OS theme).
- The six sections map to views **a–f**.

### Limitation (Confluence)
Confluence Cloud can't render the HTML (no HTML macro; it strips inline SVG). For Confluence, upload the
individual **`.svg`** files from the `diagrams*/` folders (or the matching `*-confluence-bundle.zip`).
The HTML and the SVGs are generated from the same markup, so they always match.

---

## Publishing to Confluence (Cloud) via VDI

1. Email the relevant `*-confluence-bundle.zip` to yourself (rename to `.zip.txt` first if the mail
   filter blocks zips; rename back after download).
2. In the VDI: download → **Extract All**.
3. Confluence → **Edit** → `/image` (or drag) → upload all the SVGs at once.
4. Open `legends.txt`, paste each block under its diagram.
5. **Publish.**

SVGs are light-theme (Confluence pages are light) and fully self-contained.
